﻿/*Solver.cs
 * Created By: Juliette Corpstein
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ksu.Cis300.SatisfiabilitySolver
{
    public static class Solver
    {
        
        /// <summary>
        /// Return false if not a valid formula, true if valid.
        /// </summary>
        /// <param name="var">The number of variables in the formula</param>
        /// <param name="form">The string containing the formulas</param>
        /// <returns></returns>
        private static bool IsValidFormula(string[] form, int var)
        {
            
            for (int i = 1; i < form.Length; i++)
            {
                for (int j = 0; j < form[i].Length; j++)
                {
                    if (form[i][j] < 'A' || (form[i][j] >= 'A' + var && form[i][j] < 'a'))
                    {
                        return false;
                    }
                    else if (form[i][j] >= 'a' + var)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /// <summary>
        /// Will fill the stack with false if it is not full
        /// </summary>
        /// <param name="stack">the boolean stack used to find the correct formula</param>
        /// <param name="var">Number of variables in the formula</param>
        private static void FillStack(Stack<bool> stack, int var)
        {
            if (stack.Count < var)
            {
            while (stack.Count < var)
                {
                    stack.Push(false);
                } 
            }
        }



        /// <summary>
        /// Will test to see if the boolean arrray if filled with the correct values.
        /// </summary>
        /// <param name="value">the array of true false values to check against</param>
        /// <param name="formula">the string containing the clasues</param>
        /// <returns></returns>
        private static bool IsSolution(bool[] value, string[] formula)
        {
            bool sat = true;
            for (int i = 1; i < formula.Length && sat; i++)
            {
                sat = false;
                for (int j = 0; j < formula[i].Length; j++)
                {
                    if ((Char.IsLower(formula[i][j]) && (value[formula[i][j] - 'a'] == true)) || 
                        (Char.IsUpper(formula[i][j]) && (value[formula[i][j] - 'A'] == false)))
                    {
                        sat = true;
                        break;
                    }
                    
                }//inner for
                if (sat == false)
                {
                    return false;
                }
            }//outer loop
            return true;
        }

        /// <summary>
        /// Will error check, will itterate throuh the bool stack to find a correct solution.
        /// </summary>
        /// <param name="formula">the formula containg all the </param>
        /// <param name="var"></param>
        /// <returns></returns>
        public static bool[] Solve(string[] formula, int var)
        {
            if (IsValidFormula(formula, var) == false)
            {
                throw new IOException("The formula is invalid.");
            }
            if (var > 26 || var <= 0)
            {
                throw new IOException("The number variable must be a positive interger no greater than 26.");
            }

            Stack<bool> stack = new Stack<bool>(var);
            FillStack(stack, var);

            while(stack.Count > 0)
            {
                if (stack.Count == var)
                {
                    bool[] values = stack.ToArray();
                    if (IsSolution(values, formula))
                    {
                        return values;
                    }
                }
                    bool x = stack.Pop();
                    if (!x)
                    {
                        stack.Push(true);
                        FillStack(stack, var);
                    }
            }
            return null;
        }//end solve
    }
}

