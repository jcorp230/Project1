﻿/*UserInterface.cs
 * Created By: Juliette Corpstein
 *  
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ksu.Cis300.SatisfiabilitySolver
{
    public partial class UserInterface : Form
    {
        
        public UserInterface()
        {
            InitializeComponent();
        }

        private void UserInterface_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// When you click the button you read a file then check and display solution. 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxRead_Click(object sender, EventArgs e)
        {
            uxSolution.Text = "";
            Update();
            string[] contents = new string[20];
            int _variables = 0;
            if (uxOpenFile.ShowDialog() == DialogResult.OK)
            {
               string filename = uxOpenFile.FileName;
                 contents = File.ReadAllLines(filename);

                _variables = Convert.ToInt32(contents[0]);
            }
          
            try
            {
                bool[] solution = Solver.Solve(contents, _variables);
                if (solution != null)
                    DisplaySolution(solution);
                else
                    MessageBox.Show("No Solution Found");
            }
            catch (IOException x)
            {
                MessageBox.Show(x.ToString());
            }
        }

        /// <summary>
        /// Will create the solution string from the boolean array.
        /// </summary>
        /// <param name="solution">The boolean array containging the solution</param>
        private void DisplaySolution(bool[] solution)
        {

            StringBuilder sb = new StringBuilder();

           for (int i = 0; i < solution.Length; i++)
                {
                    if (solution[i] == true)
                    {
                        char lower = Convert.ToChar('a' + i);
                        sb.Append(lower);
                    }
                    if (solution[i] == false)
                    {
                        char upper = Convert.ToChar('A' + i);
                        sb.Append(upper);
                    }
                }
                uxSolution.Text = sb.ToString();
            }
        }
    }
