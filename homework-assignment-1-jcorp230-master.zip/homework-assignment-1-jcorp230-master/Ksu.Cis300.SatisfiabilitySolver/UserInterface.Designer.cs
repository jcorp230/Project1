﻿namespace Ksu.Cis300.SatisfiabilitySolver
{
    partial class UserInterface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.uxRead = new System.Windows.Forms.Button();
            this.uxSolution = new System.Windows.Forms.TextBox();
            this.uxSolutionLabel = new System.Windows.Forms.Label();
            this.uxOpenFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // uxRead
            // 
            this.uxRead.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxRead.Location = new System.Drawing.Point(37, 22);
            this.uxRead.Name = "uxRead";
            this.uxRead.Size = new System.Drawing.Size(423, 69);
            this.uxRead.TabIndex = 0;
            this.uxRead.Text = "Read Formula";
            this.uxRead.UseVisualStyleBackColor = true;
            this.uxRead.Click += new System.EventHandler(this.uxRead_Click);
            // 
            // uxSolution
            // 
            this.uxSolution.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSolution.Location = new System.Drawing.Point(181, 103);
            this.uxSolution.Multiline = true;
            this.uxSolution.Name = "uxSolution";
            this.uxSolution.ReadOnly = true;
            this.uxSolution.Size = new System.Drawing.Size(279, 45);
            this.uxSolution.TabIndex = 1;
            // 
            // uxSolutionLabel
            // 
            this.uxSolutionLabel.AutoSize = true;
            this.uxSolutionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.uxSolutionLabel.Location = new System.Drawing.Point(41, 103);
            this.uxSolutionLabel.Name = "uxSolutionLabel";
            this.uxSolutionLabel.Size = new System.Drawing.Size(137, 32);
            this.uxSolutionLabel.TabIndex = 2;
            this.uxSolutionLabel.Text = "Solution:";
            // 
            // uxOpenFile
            // 
            this.uxOpenFile.FileName = "openFileDialog1";
            this.uxOpenFile.Filter = "Text files|*.txt|All files|*.* ";
            // 
            // UserInterface
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(504, 167);
            this.Controls.Add(this.uxSolutionLabel);
            this.Controls.Add(this.uxSolution);
            this.Controls.Add(this.uxRead);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UserInterface";
            this.Text = "Satisfiability Solver";
            this.Load += new System.EventHandler(this.UserInterface_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button uxRead;
        private System.Windows.Forms.TextBox uxSolution;
        private System.Windows.Forms.Label uxSolutionLabel;
        private System.Windows.Forms.OpenFileDialog uxOpenFile;
    }
}

